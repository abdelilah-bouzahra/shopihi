const cron = require('node-cron');
import { sync } from './routes/app._index';

cron.schedule('*/1 * * * *', async () => {
  try {
    await sync();
  } catch (error) {
    console.error('Error during sync:', error);
  }
});

module.exports = cron;
